package cl.lefrog.hermesbluetooth;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.List;

public class MainActivity extends Activity {
    private AudioManager audio;
    private TextView log;
    private LinearLayout root;
    private volatile boolean busy = false;
    private AudioDeviceInfo selected;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final int RATE = 16000;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        audio = (AudioManager)getSystemService(AUDIO_SERVICE);
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,24,24,24);
        scroll.addView(root); setContentView(scroll);
        addButton("1. Conceder permisos", () -> requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.BLUETOOTH_CONNECT}, 1));
        addButton("2. Buscar dispositivos de comunicación", this::scan);
        addButton("3. Grabar 5 segundos y reproducir", this::test);
        addButton("Desactivar ruta Bluetooth", () -> { if (!busy) { audio.clearCommunicationDevice(); audio.setMode(AudioManager.MODE_NORMAL); selected=null; append("Ruta restaurada"); }});
        log = new TextView(this); log.setTextSize(15); root.addView(log);
        append("Conecta el Redmi Watch 5 Lite por Bluetooth, concede permisos y busca dispositivos. Selecciona el reloj si aparece.");
    }
    private void addButton(String title, Runnable action) {
        Button b = new Button(this); b.setText(title); root.addView(b); b.setOnClickListener(v -> action.run());
    }
    private void append(String s) { main.post(() -> log.append(s + "\n\n")); }
    private boolean permitted() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED) {
            append("Faltan permisos: pulsa el botón 1."); return false;
        } return true;
    }
    private void scan() {
        if (!permitted() || busy) return;
        List<AudioDeviceInfo> devices = audio.getAvailableCommunicationDevices();
        append("Dispositivos de comunicación encontrados: " + devices.size());
        for (AudioDeviceInfo device : devices) {
            String name = device.getProductName().toString();
            append("ID=" + device.getId() + " / tipo=" + device.getType() + " / " + name);
            addButton("Usar: " + name + " (tipo " + device.getType() + ")", () -> select(device));
        }
        append("Tipo 7 = Bluetooth SCO. Si no aparece el reloj, la API no lo está exponiendo como dispositivo de comunicación en este momento.");
    }
    private void select(AudioDeviceInfo device) {
        if (!permitted() || busy) return;
        try {
            audio.setMode(AudioManager.MODE_IN_COMMUNICATION);
            boolean ok = audio.setCommunicationDevice(device);
            selected = ok ? device : null;
            append("Selección de ruta: " + ok + " / " + device.getProductName());
        } catch (Exception e) { append("Error seleccionando: " + e); }
    }
    private void test() {
        if (!permitted() || busy) return;
        if (selected == null) { append("Primero selecciona un dispositivo de la lista."); return; }
        busy = true;
        new Thread(() -> {
            AudioRecord recorder = null; AudioTrack player = null;
            try {
                int min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                int size = Math.max(min, RATE * 2);
                recorder = new AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size);
                if (recorder.getState() != AudioRecord.STATE_INITIALIZED) throw new Exception("AudioRecord no inicializó");
                byte[] capture = new byte[RATE * 2 * 5];
                append("Grabando 5 segundos... habla al reloj.");
                recorder.startRecording();
                int pos = 0;
                while (pos < capture.length) {
                    int n = recorder.read(capture, pos, Math.min(size, capture.length - pos));
                    if (n <= 0) throw new Exception("Error AudioRecord: " + n);
                    pos += n;
                }
                append("Micrófono enrutado a: " + (recorder.getRoutedDevice()==null ? "desconocido" : recorder.getRoutedDevice().getProductName()));
                recorder.stop(); recorder.release(); recorder = null;
                int outMin = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
                player = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(new AudioFormat.Builder().setSampleRate(RATE).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(Math.max(outMin, RATE * 2)).setTransferMode(AudioTrack.MODE_STREAM).build();
                if (player.getState() != AudioTrack.STATE_INITIALIZED) throw new Exception("AudioTrack no inicializó");
                player.play();
                append("Reproduciendo audio grabado...");
                int sent=0;
                while (sent < pos) {
                    int n=player.write(capture, sent, pos-sent);
                    if (n <= 0) throw new Exception("Error AudioTrack: " + n);
                    sent += n;
                }
                append("Altavoz enrutado a: " + (player.getRoutedDevice()==null ? "desconocido" : player.getRoutedDevice().getProductName()));
                Thread.sleep(1000);
                append("Prueba terminada. ¿Escuchaste tu voz en el reloj o en el teléfono?");
            } catch (Exception e) { append("ERROR: " + e); }
            finally {
                if (recorder!=null) { try { if(recorder.getRecordingState()==AudioRecord.RECORDSTATE_RECORDING) recorder.stop(); recorder.release(); } catch(Exception ignored){} }
                if (player!=null) { try { player.stop(); player.release(); } catch(Exception ignored){} }
                busy=false;
            }
        }).start();
    }
    @Override protected void onDestroy() {
        if (!busy) { audio.clearCommunicationDevice(); audio.setMode(AudioManager.MODE_NORMAL); }
        super.onDestroy();
    }
}
